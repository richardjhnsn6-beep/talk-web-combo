const Podcast = () => {
  const episodes = [
    {
      id: 1,
      title: "RJHNSN12 - Shem, Ham, and Japheth Explained",
      description: "RJHNSN12 teaching about the three sons of Noah and their connection to biblical history.",
      pageLink: "/page-three",
      videoUrl: "https://www.youtube.com/embed/U_2QiZV_xEU"
    },
    {
      id: 2,
      title: "Shaka Zulu Coronation 1816",
      description: "RJHNSN12 Original: Edited documentary about Shaka Zulu's coronation in 1816 and connection to Deuteronomy 33:20-21.",
      pageLink: "/page-two",
      videoUrl: "https://www.youtube.com/embed/cCwKGVOaW1Y"
    },
    {
      id: 3,
      title: "Pastor Ray Hagins - Kemet Egypt Ancient Wisdom",
      description: "The source of the Bible from ancient Egypt (Kemet), understanding the ancient name meaning 'black'.",
      pageLink: "/page-three",
      videoUrl: "https://www.youtube.com/embed/09w-ZFasRvE"
    },
    {
      id: 4,
      title: "Journey Through Ancient Egypt",
      description: "3D Egyptian temple journey - Experience the ancient stones and sacred spaces with music by RJHNSN12.",
      pageLink: "/",
      videoUrl: "https://drive.google.com/file/d/0B73CQ06mcqAYOEhrdVp2Tm51YXc/preview"
    },
    {
      id: 5,
      title: "Serapis Christus - The Truth Revealed",
      description: "Mix clips featuring Louis Farrakhan and Dr. Ray Hagins discussing Serapis Christus and biblical history.",
      pageLink: "/page-four",
      videoUrl: "https://drive.google.com/file/d/1jhWW95o0xKU39bABm0SOEIGeEASsABWQ/preview"
    },
    {
      id: 6,
      title: "Movement - Who is Israel?",
      description: "Rodney King, police brutality, Black lives lost. Hebrew documentation with Lil Wayne and Game music.",
      pageLink: "/page-five",
      videoUrl: "https://drive.google.com/file/d/12kQtEILC5NjqQIfSANnHa6YxuZsht_aG/preview"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white" data-testid="podcast-page">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-700 to-teal-600 py-8 px-8 shadow-lg">
        <h1 className="text-4xl md:text-5xl font-bold text-yellow-300 text-center" data-testid="page-title">
          RJHNSN12 - Biblical Truth Video Podcast
        </h1>
        <p className="text-center text-white mt-3 text-lg">
          All Video Teachings in One Place
        </p>
      </div>

      <div className="max-w-6xl mx-auto p-8">
        {/* Radio Notice */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg shadow-lg p-6 mb-8 text-center">
          <p className="text-white text-lg font-semibold">
            🎵 <strong>Listening to our radio?</strong> Please pause the radio player at the bottom before watching videos! ⏸️
          </p>
          <p className="text-white/90 text-sm mt-2">
            (Look for the purple player bar at the bottom of your screen)
          </p>
        </div>

        {/* Introduction */}
        <div className="bg-white rounded-lg shadow-xl p-8 mb-8">
          <h2 className="text-3xl font-bold text-teal-800 mb-4" data-testid="intro-title">
            Video Podcast Hub
          </h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Welcome to the complete collection of video teachings on Hebrew Torah, biblical truth, and the connection 
            between ancient wisdom and Black heritage. Browse all episodes below and click to watch.
          </p>
        </div>

        {/* Radio Station Promo Banner */}
        <div className="mb-8">
          <a href="/radio" className="block group">
            <img 
              src="https://static.prod-images.emergentagent.com/jobs/dae91dca-f806-499e-ba09-9fd13250539c/images/488f7794704750350163d5d56b98fbcdb983d8f2b489445ffb99950393fbbd5c.png"
              alt="Listen to RJHNSN12 Radio 24/7"
              className="w-full h-48 object-cover rounded-lg shadow-lg group-hover:shadow-2xl transition-all"
            />
          </a>
        </div>

        {/* Episodes Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {episodes.map((episode) => (
            <div 
              key={episode.id} 
              className="bg-white rounded-lg shadow-xl overflow-hidden hover:shadow-2xl transition-shadow"
              data-testid={`episode-${episode.id}`}
            >
              {/* Video Preview - Smaller */}
              <div className="relative" style={{ paddingBottom: '56.25%' }}>
                <iframe
                  className="absolute top-0 left-0 w-full h-full"
                  src={episode.videoUrl}
                  title={episode.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
              
              {/* Episode Info */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-teal-800 mb-2">
                  Episode {episode.id}: {episode.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  {episode.description}
                </p>
                <a 
                  href={episode.pageLink}
                  className="inline-block bg-teal-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-teal-700 transition-colors"
                >
                  Watch Full Episode →
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-12 bg-gradient-to-r from-teal-700 to-teal-600 rounded-lg p-8 text-white text-center shadow-xl">
          <h3 className="text-2xl font-bold mb-4">Contact Us</h3>
          <p className="text-lg mb-6">
            Have questions about these teachings? Want to learn more about Hebrew Torah truth and ancient wisdom? Get in touch.
          </p>
          <a 
            href="/contact" 
            className="inline-block bg-white text-teal-700 px-8 py-3 rounded-lg font-bold hover:bg-yellow-300 transition-colors"
            data-testid="contact-link"
          >
            Contact Us
          </a>
        </div>
      </div>
    </div>
  );
};

export default Podcast;
